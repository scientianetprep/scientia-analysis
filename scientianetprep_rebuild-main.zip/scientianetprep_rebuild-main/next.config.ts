import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  // Build-time optimisations.
  //
  // `optimizePackageImports` rewrites barrel-style imports like
  //   `import { Loader2, CheckCircle2 } from "lucide-react"`
  // into per-file imports at compile time, which avoids pulling the whole
  // ~1400-icon lucide-react index into every route's module graph. This is
  // the single biggest lever for us: 55 files currently import from
  // lucide-react, plus date-fns (10 files) and framer-motion (13 files),
  // all of which publish barrel indexes that Turbopack would otherwise
  // have to walk fully.
  experimental: {
    optimizePackageImports: [
      "lucide-react",
      "date-fns",
      "framer-motion",
      "recharts",
    ],
  },

  // Mark server-only native deps as external so Turbopack doesn't try to
  // bundle them into Route Handlers. `sharp` has a native binary and is
  // required by next/image; `@supabase/ssr` re-exports cookies helpers
  // that are easier to leave as CommonJS externals.
  //
  // (Note: Next.js 16 no longer auto-runs ESLint during `next build`, so
  // the old `eslint.ignoreDuringBuilds` escape hatch is unnecessary and in
  // fact removed from the NextConfig type.)
  serverExternalPackages: ["sharp", "@supabase/ssr", "@supabase/supabase-js"],

  // Remote images used by the app (Supabase public bucket + any seeded
  // placeholders). Keeping this explicit avoids runtime image-loader
  // crashes on the first request.
  images: {
    remotePatterns: [
      {
        protocol: "https",
        hostname: "*.supabase.co",
        pathname: "/storage/v1/object/public/**",
      },
    ],
  },
};

export default nextConfig;
